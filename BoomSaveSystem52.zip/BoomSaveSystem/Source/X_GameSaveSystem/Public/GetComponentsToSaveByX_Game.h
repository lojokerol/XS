﻿// Author: DS_Long
// Publication: 2024-5-24

#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "GetComponentsToSaveByX_Game.generated.h"

// This class does not need to be modified.
UINTERFACE(BlueprintType,Blueprintable)
class UGetComponentsToSaveByX_Game : public UInterface
{
	GENERATED_BODY()
};

/**
 * 
 */
class X_GAMESAVESYSTEM_API IGetComponentsToSaveByX_Game
{
	GENERATED_BODY()

	
public:
	/*接口：选择该对象下需要存储的对象*/
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable,Category="XGame | Save")
	TArray<UObject*> GetChildObjects();

	/*用于数据更新后的一系列操作*/
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable,Category="XGame | Save")
	void OnActorLoad();

	/*用于数据c存储后后的一系列操作*/
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable,Category="XGame | Save")
	void OnActorSave();

	/*通过类而不是场景中的Name进行序列化，这里用于控制器和角色*/
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable,Category="XGame | Save")
	bool CustomSaveByClass();

	// /*是否自定义时机通过SaveSystem进行反序列化*/
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable,Category="XGame | Save")
	bool CustomLoad();
};
