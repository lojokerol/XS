// Author: DS_Long
// Publication: 2024-5-24
#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

class FX_GameSaveSystemModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
};
