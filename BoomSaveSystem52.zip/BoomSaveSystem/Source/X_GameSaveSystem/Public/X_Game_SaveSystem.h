// Author: DS_Long
// Publication: 2024-5-24

#pragma once

#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "X_Game_SaveSystem.generated.h"

struct FSaveActorData;
class USaveActorsDataSlot;
DECLARE_DYNAMIC_DELEGATE(FSaveWorldState);

class UX_GameCharacterSaveGame;
/**
 * 
 */
UCLASS(Blueprintable,Blueprintable)
class X_GAMESAVESYSTEM_API UX_Game_SaveSystem : public UGameInstanceSubsystem
{
	GENERATED_BODY()

public:
	/*
	 * IsObjectSaveGame: 传入的UObject是否根据SaveGame标识符序列化数据
	 * IsChildObjectsSaveGame: 传入的在父UObject上的Objects是否通过SaveGame标识符存储
	 */
	UFUNCTION(BlueprintCallable,Category="SaveGameSystem")
	void SaveObject(UObject* SaveObject, const FString SlotName, const bool IsObjectSaveGame = false, const bool IsChildObjectsSaveGame = false);
	
	/* DeSerializeSelfActor: 是否直接修改传入Actor或返回一个新的Actor指针不会影响传入Actor*/
	UFUNCTION(BlueprintCallable,Category="SaveGameSystem")
	UObject* LoadObject(TArray<UObject*>& childObjects, UObject* LoadObject, FString SlotName, bool DeSerializeSelfActor = false, bool IsObjectSaveGame = false, bool IsChildObjectSaveGame = false);

	class UX_GameCharacterSaveGame* SerializeActor(UObject* InObject, bool IsSaveGame = false, bool IsChildObjectSaveGame = false);

	void SerializeComponents(UObject* InObject, UX_GameCharacterSaveGame* SaveData, bool IsChildObjectSaveGame = false);

	void DeserializeComponents(TArray<UObject*>& ChildObjects, UObject* actor, UX_GameCharacterSaveGame* SaveData, bool IsSaveGame = false, bool IsChildObjectSaveGame = false);



#pragma region SaveWorld
	UFUNCTION(BlueprintCallable,Category="SaveGameSystem")
	void SaveWorld(FSaveWorldState OnSaveWorldSuccess, const UObject* WorldContext, FString SlotName, FString Date, TArray<FString> OtherDataArr);

	USaveActorsDataSlot* SaveActor_Native(const UObject* WorldContext,FString SlotName, FString Date, TArray<FString> OtherDataArr);
	
	void SerializeComponents_Native(UObject* InObject, FSaveActorData& SaveData);
	
	UFUNCTION(BlueprintCallable,Category="SaveGameSystem")
	void LoadWorld(FSaveWorldState OnLoadWorldSuccess, const UObject* WorldContext, FString SlotName, bool bReOpenLevel, bool bAbsolute = true, FString Options = FString(""));

	void LoadWorld_Native(const UObject* WorldContext, FString SlotName);
	
	void LoadActor_Native(UObject* LoadObject, FSaveActorData* actorData);
	void DeserializeComponents_Native(UObject* LoadObject, FSaveActorData* actorData);

	UFUNCTION(BlueprintCallable,Category="SaveGameSystem")
	void CustomDeserializeByActorName(AActor* InActor, FString SlotName, FString ObjectName);
	
	UFUNCTION(BlueprintCallable,Category="SaveGameSystem")
	void LoadWorldBP(UObject* WorldContext);
	
	UPROPERTY(BlueprintReadWrite,Category="SaveGameSystem")
	FString LoadWorldSlotName;

#pragma endregion 
};
