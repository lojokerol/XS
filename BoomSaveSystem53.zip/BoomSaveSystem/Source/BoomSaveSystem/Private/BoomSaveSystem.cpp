﻿// Author: DS_Long
// Publication: 2024-5-24

#include "BoomSaveSystem.h"

#define LOCTEXT_NAMESPACE "FBoomSaveSystemModule"

void FBoomSaveSystemModule::StartupModule()
{
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module
}

void FBoomSaveSystemModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FBoomSaveSystemModule, BoomSaveSystem)