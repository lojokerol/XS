
// Author: DS_Long
// Publication: 2024-5-24

#include "X_Game_SaveSystem.h"

#include "GetComponentsToSaveByX_Game.h"
#include "X_GameCharacterSaveGame.h"
#include "Kismet/GameplayStatics.h"
#include "Serialization/ObjectAndNameAsStringProxyArchive.h"
#include "Serialization/MemoryReader.h"
#include "Serialization/MemoryWriter.h"
#include "Engine/World.h"
#include "Engine/GameInstance.h"

void UX_Game_SaveSystem::SaveObject(UObject* SaveObject, const FString SlotName, const bool IsObjectSaveGame, const bool IsChildObjectSaveGame)
{
	UX_GameCharacterSaveGame* SaveGameIns = Cast<UX_GameCharacterSaveGame>(UGameplayStatics::LoadGameFromSlot(SlotName,0));
	if(!SaveGameIns)
	{
		SaveGameIns = Cast<UX_GameCharacterSaveGame>(UGameplayStatics::CreateSaveGameObject(UX_GameCharacterSaveGame::StaticClass()));
	}
	const UX_GameCharacterSaveGame* SerialData = SerializeActor(SaveObject, IsObjectSaveGame, IsChildObjectSaveGame);
	if (SerialData)
	{
		SaveGameIns->PtrData = SerialData->PtrData;
		SaveGameIns->ComponentsData = SerialData->ComponentsData;
		UGameplayStatics::SaveGameToSlot(SaveGameIns,SlotName,0);
	}
}


UObject* UX_Game_SaveSystem::LoadObject(TArray<UObject*>& childObjects, UObject* LoadObject, FString SlotName, bool DeSerializeSelfActor, bool IsObjectSaveGame, bool IsChildObjectSaveGame)
{
	UX_GameCharacterSaveGame* SaveGameIns = Cast<UX_GameCharacterSaveGame>(UGameplayStatics::LoadGameFromSlot(SlotName, 0));
	if(!SaveGameIns) return nullptr;
	if(DeSerializeSelfActor)
	{
		FMemoryReader MemoryReader(SaveGameIns->PtrData, true);
		FObjectAndNameAsStringProxyArchive Ar(MemoryReader, false);
		Ar.ArIsSaveGame = IsObjectSaveGame;
		Ar.ArNoDelta = false;
		LoadObject->Serialize(Ar);
		DeserializeComponents(childObjects, LoadObject, SaveGameIns, IsChildObjectSaveGame, DeSerializeSelfActor);
		return LoadObject;
	}
	else
	{
		// UObject* NewActor = NewObject<UObject>(actor,actor->GetClass());
		UObject* NewActor = UGameplayStatics::SpawnObject(LoadObject->GetClass(),LoadObject);
		FMemoryReader MemoryReader(SaveGameIns->PtrData, true);
		FObjectAndNameAsStringProxyArchive Ar(MemoryReader, false);
		Ar.ArIsSaveGame = IsObjectSaveGame;
		Ar.ArNoDelta = false;
		NewActor->Serialize(Ar);
		DeserializeComponents(childObjects, NewActor, SaveGameIns, IsChildObjectSaveGame, DeSerializeSelfActor);
		return NewActor;
	}

}

UX_GameCharacterSaveGame* UX_Game_SaveSystem::SerializeActor(UObject* InObject, bool IsSaveGame, bool IsChildObjectSaveGame)
{
	UX_GameCharacterSaveGame* Record = NewObject<UX_GameCharacterSaveGame>();
	SerializeComponents(InObject, Record, IsChildObjectSaveGame);
	FMemoryWriter MemoryWriter(Record->PtrData, true);
	FObjectAndNameAsStringProxyArchive Ar(MemoryWriter, false);
	Ar.ArIsSaveGame = IsSaveGame;
	Ar.ArNoDelta = false;
	InObject->Serialize(Ar);
	return Record;
}

void UX_Game_SaveSystem::SerializeComponents(UObject* InObject, UX_GameCharacterSaveGame* SaveData, bool IsChildObjectSaveGame)
{
	if(!InObject) return;
	bool bImplements = InObject->GetClass()->ImplementsInterface(UGetComponentsToSaveByX_Game::StaticClass());
	
	if(!bImplements) return;
	 TArray<UObject*> Components = IGetComponentsToSaveByX_Game::Execute_GetChildObjects(InObject);
	if(Components.Num()>0)
	{
		for (auto Component : Components)
		{
			if(!Component) continue;
			FComponentData ComData;
			if(Component && Component->GetClass())
			{
				ComData.PtrClass = Component->GetClass();
				FMemoryWriter MemoryWriter(ComData.PtrData, true);
				FObjectAndNameAsStringProxyArchive Ar(MemoryWriter, false);
				Ar.ArIsSaveGame = IsChildObjectSaveGame;
				Ar.ArNoDelta = false;
				Component->Serialize(Ar);
				SaveData->ComponentsData.Add(ComData);
			}
		}
	}

}


void UX_Game_SaveSystem::DeserializeComponents(TArray<UObject*>& ChildObjects, UObject* actor, UX_GameCharacterSaveGame* SaveData, bool IsChildObjectSaveGame, bool DeSerializeSelfActor)
{
	if(DeSerializeSelfActor)
	{
		bool bImplements = actor->GetClass()->ImplementsInterface(UGetComponentsToSaveByX_Game::StaticClass());
		if(!bImplements) return;
		TArray<UObject*> Objects = IGetComponentsToSaveByX_Game::Execute_GetChildObjects(actor);
		if(Objects.Num()>0)
		{
			for (UObject* Obj : Objects)
			{
				if(Obj && Obj->GetClass())
				{
					const UClass* ComClass = Obj->GetClass();
					FComponentData* ComData = SaveData->ComponentsData.FindByKey(ComClass);
					if (ComData)
					{
						FMemoryReader MemoryReader(ComData->PtrData, true);
						FObjectAndNameAsStringProxyArchive Ar(MemoryReader, false);
						Ar.ArIsSaveGame = IsChildObjectSaveGame;
						Ar.ArNoDelta = false;
						Obj->Serialize(Ar);
					}
				}
			}
			ChildObjects = {};
		}
	}
	else
	{
		bool bImplements = actor->GetClass()->ImplementsInterface(UGetComponentsToSaveByX_Game::StaticClass());
		if(!bImplements) return;
		TArray<UObject* > Objects = IGetComponentsToSaveByX_Game::Execute_GetChildObjects(actor);
		if(Objects.Num()>0)
		{
			for (UObject* Obj : Objects)
			{
				if(!Obj) continue;
				UObject* NewObj = Cast<UObject>(UGameplayStatics::SpawnObject(Obj->GetClass(),actor));
				if(NewObj)
				{
					const UClass* ComClass = Obj->GetClass();
					FComponentData* ComData = SaveData->ComponentsData.FindByKey(ComClass);
					FMemoryReader MemoryReader(ComData->PtrData, true);
					FObjectAndNameAsStringProxyArchive Ar(MemoryReader, false);
					Ar.ArIsSaveGame = IsChildObjectSaveGame;
					Ar.ArNoDelta = false;
					NewObj->Serialize(Ar);
					ChildObjects.Add(NewObj);
				}
			}
		}
	}
}

void UX_Game_SaveSystem::SaveWorld(FSaveWorldState OnSaveWorldSuccess, const UObject*  WorldContext,FString SlotName, FString Date, TArray<FString> OtherDataArr)
{
	USaveActorsDataSlot* SaveGameIns = Cast<USaveActorsDataSlot>(UGameplayStatics::LoadGameFromSlot(SlotName,0));
	if(!SaveGameIns)
	{
		SaveGameIns = Cast<USaveActorsDataSlot>(UGameplayStatics::CreateSaveGameObject(USaveActorsDataSlot::StaticClass()));
	}
	const USaveActorsDataSlot* SerialData = SaveActor_Native(WorldContext,SlotName,Date,OtherDataArr);
	if (SerialData)
	{
		SaveGameIns->SlotName = SlotName;
		SaveGameIns->actorsSlotData = SerialData->actorsSlotData;
		SaveGameIns->Date = Date;
		SaveGameIns->MapName = UGameplayStatics::GetCurrentLevelName(WorldContext);;
		SaveGameIns->OtherDataArr = OtherDataArr;
		UGameplayStatics::SaveGameToSlot(SaveGameIns,SlotName,0);
		OnSaveWorldSuccess.Execute();
	}
	
}

USaveActorsDataSlot* UX_Game_SaveSystem::SaveActor_Native(const UObject*  WorldContext, FString SlotName, FString Date, TArray<FString> OtherDataArr)
{
	USaveActorsDataSlot* Record = NewObject<USaveActorsDataSlot>();
	Record->Date = Date;
	Record->SlotName = SlotName;
	Record->OtherDataArr = OtherDataArr;
	TArray<AActor*> SaveActors;
	UGameplayStatics::GetAllActorsWithInterface(WorldContext, UGetComponentsToSaveByX_Game::StaticClass(), SaveActors);
	if(SaveActors.IsEmpty()) return Record;
	
	for (auto SaveActor : SaveActors)
	{
		if(SaveActor->Implements<UGetComponentsToSaveByX_Game>())
		{
			IGetComponentsToSaveByX_Game::Execute_OnActorSave(SaveActor);
		}
		FSaveActorData SaveActorData;
		SaveActorData.ActorClass = SaveActor->GetClass();
		SaveActorData.ObjectName = SaveActor->GetName();
		SaveActorData.Transform = SaveActor->GetTransform();
		SerializeComponents_Native(SaveActor, SaveActorData);
		FMemoryWriter MemoryWriter(SaveActorData.PtrData, true);
		FObjectAndNameAsStringProxyArchive Ar(MemoryWriter, false);
		Ar.ArIsSaveGame = true;
		Ar.ArNoDelta = false;
		SaveActor->Serialize(Ar);
		Record->actorsSlotData.Add(SaveActorData);
	}
	return Record;
}

void UX_Game_SaveSystem::SerializeComponents_Native(UObject* InObject, FSaveActorData& SaveData)
{
	if(!InObject) return;
	bool bImplements = InObject->GetClass()->ImplementsInterface(UGetComponentsToSaveByX_Game::StaticClass());
	
	if(!bImplements) return;
	TArray<UObject*> Components = IGetComponentsToSaveByX_Game::Execute_GetChildObjects(InObject);
	if(Components.Num()>0)
	{
		for (auto Component : Components)
		{
			if(!Component) continue;
			FComponentData ComData;
			if(Component && Component->GetClass())
			{
				if(Component->Implements<UGetComponentsToSaveByX_Game>())
				{
					IGetComponentsToSaveByX_Game::Execute_OnActorSave(Component);
				}
				ComData.PtrClass = Component->GetClass();
				ComData.ObjectName = Component->GetName();
				FMemoryWriter MemoryWriter(ComData.PtrData, true);
				FObjectAndNameAsStringProxyArchive Ar(MemoryWriter, false);
				Ar.ArIsSaveGame = true;
				Ar.ArNoDelta = false;
				Component->Serialize(Ar);
				SaveData.ComponentsData.Add(ComData);
			}
		}
	}
}

void UX_Game_SaveSystem::LoadWorld(FSaveWorldState OnLoadWorldSuccess, const UObject*  WorldContext, FString SlotName, bool bReOpenLevel, bool bAbsolute, FString Options)
{
	
	USaveActorsDataSlot* SaveGameIns = Cast<USaveActorsDataSlot>(UGameplayStatics::LoadGameFromSlot(SlotName, 0));
	if(!SaveGameIns) return;
	
	UWorld* world = WorldContext->GetWorld();
	if(bReOpenLevel)
	{
		LoadWorldSlotName = SlotName;
		UGameplayStatics::OpenLevel(WorldContext, FName(SaveGameIns->MapName), bAbsolute, Options);
	}
	else
	{
		LoadWorldSlotName = FString();
		TArray<AActor*> LoadActors;
	
		TArray<FSaveActorData> NeedToBeReSpawnActorData = SaveGameIns->actorsSlotData;
	
		if (world) {
			UGameplayStatics::GetAllActorsWithInterface(world, UGetComponentsToSaveByX_Game::StaticClass(), LoadActors);
	
			if (UX_Game_SaveSystem* XGameSaveSysytem = world->GetGameInstance()->GetSubsystem<UX_Game_SaveSystem>())
			{
				for (auto actor : LoadActors) {
					if (IGetComponentsToSaveByX_Game::Execute_CustomSaveByClass(actor))
					{
						FSaveActorData* actorData = SaveGameIns->actorsSlotData.FindByKey(actor->GetClass());
						if(actorData)
						{
							XGameSaveSysytem->LoadActor_Native(actor,actorData);
							actor->SetActorTransform(actorData->Transform);
							if (NeedToBeReSpawnActorData.Num()>0)
							{
								NeedToBeReSpawnActorData.RemoveSingle(*actorData);
							}
						}
						continue;
					}
					FSaveActorData* actorData = SaveGameIns->actorsSlotData.FindByKey(actor->GetName());
					if(actorData)
					{
						XGameSaveSysytem->LoadActor_Native(actor,actorData);
						actor->SetActorTransform(actorData->Transform);
						if (NeedToBeReSpawnActorData.Num()>0)
						{
							NeedToBeReSpawnActorData.RemoveSingle(*actorData);
						}
					}
				}
				OnLoadWorldSuccess.Execute();

				if (NeedToBeReSpawnActorData.IsEmpty()) return;
	
				for (auto& ToBeReSpawnActorData : NeedToBeReSpawnActorData)
				{
					FActorSpawnParameters SpawnParameters;
					auto CustomLoadActor = Cast<AActor>(ToBeReSpawnActorData.ActorClass->GetDefaultObject());
					if(CustomLoadActor && CustomLoadActor->Implements<UGetComponentsToSaveByX_Game>())
					{
						if (IGetComponentsToSaveByX_Game::Execute_CustomLoad(CustomLoadActor))
						{
							continue;
						}
					}
					auto actor = world->SpawnActor(ToBeReSpawnActorData.ActorClass,&ToBeReSpawnActorData.Transform);
					if(actor)
					{
						XGameSaveSysytem->LoadActor_Native(actor,&ToBeReSpawnActorData);
						actor->SetActorTransform(ToBeReSpawnActorData.Transform);
					}
				}
			}
		}
	}

	// (new FAutoDeleteAsyncTask<LoadWorldTask>(OnLoadWorldSuccess,WorldContext,SaveGameIns))->StartBackgroundTask();
	
}

void UX_Game_SaveSystem::LoadWorld_Native(const UObject* WorldContext, FString SlotName)
{
	USaveActorsDataSlot* SaveGameIns = Cast<USaveActorsDataSlot>(UGameplayStatics::LoadGameFromSlot(SlotName, 0));
	if(!SaveGameIns) return;
	
	UWorld* world = WorldContext->GetWorld();
	
	TArray<AActor*> LoadActors;
	
	TArray<FSaveActorData> NeedToBeReSpawnActorData = SaveGameIns->actorsSlotData;
	
	if (world) {
		UGameplayStatics::GetAllActorsWithInterface(world, UGetComponentsToSaveByX_Game::StaticClass(), LoadActors);
	
		if (UX_Game_SaveSystem* XGameSaveSysytem = world->GetGameInstance()->GetSubsystem<UX_Game_SaveSystem>())
		{
			for (auto actor : LoadActors) {
				if (IGetComponentsToSaveByX_Game::Execute_CustomSaveByClass(actor))
				{
					FSaveActorData* actorData = SaveGameIns->actorsSlotData.FindByKey(actor->GetClass());
					if(actorData)
					{
						XGameSaveSysytem->LoadActor_Native(actor,actorData);
						actor->SetActorTransform(actorData->Transform);
						if (NeedToBeReSpawnActorData.Num()>0)
						{
							NeedToBeReSpawnActorData.RemoveSingle(*actorData);
						}
					}
					continue;
				}
				FSaveActorData* actorData = SaveGameIns->actorsSlotData.FindByKey(actor->GetName());
				if(actorData)
				{
					XGameSaveSysytem->LoadActor_Native(actor,actorData);
					actor->SetActorTransform(actorData->Transform);
					if (NeedToBeReSpawnActorData.Num()>0)
					{
						NeedToBeReSpawnActorData.RemoveSingle(*actorData);
					}
				}
			}

			if (NeedToBeReSpawnActorData.IsEmpty()) return;
	
			for (auto& ToBeReSpawnActorData : NeedToBeReSpawnActorData)
			{
				FActorSpawnParameters SpawnParameters;
				auto CustomLoadActor = Cast<AActor>(ToBeReSpawnActorData.ActorClass->GetDefaultObject());
				if(CustomLoadActor && CustomLoadActor->Implements<UGetComponentsToSaveByX_Game>())
				{
					if (IGetComponentsToSaveByX_Game::Execute_CustomLoad(CustomLoadActor))
					{
						continue;
					}
				}
				auto actor = world->SpawnActor(ToBeReSpawnActorData.ActorClass,&ToBeReSpawnActorData.Transform);
				if(actor)
				{
	
					XGameSaveSysytem->LoadActor_Native(actor,&ToBeReSpawnActorData);
					actor->SetActorTransform(ToBeReSpawnActorData.Transform);
				}
			}
		}
	}
}


void UX_Game_SaveSystem::LoadActor_Native(UObject* LoadObject, FSaveActorData* actorData)
{
		FMemoryReader MemoryReader(actorData->PtrData, true);
		FObjectAndNameAsStringProxyArchive Ar(MemoryReader, false);
		Ar.ArIsSaveGame = true;
		Ar.ArNoDelta = false;
		LoadObject->Serialize(Ar);
		DeserializeComponents_Native(LoadObject, actorData);
		if(LoadObject->Implements<UGetComponentsToSaveByX_Game>())
		{
			IGetComponentsToSaveByX_Game::Execute_OnActorLoad(LoadObject);
		}
}

void UX_Game_SaveSystem::DeserializeComponents_Native(UObject* LoadObject, FSaveActorData* actorData)
{
	bool bImplements = LoadObject->GetClass()->ImplementsInterface(UGetComponentsToSaveByX_Game::StaticClass());
	if(!bImplements) return;
	TArray<UObject*> Objects = IGetComponentsToSaveByX_Game::Execute_GetChildObjects(LoadObject);
	if(Objects.Num()>0)
	{
		for (UObject* Obj : Objects)
		{
			if(Obj && Obj->GetClass())
			{
				const UClass* ComClass = Obj->GetClass();
				FComponentData* ComData = actorData->ComponentsData.FindByKey(ComClass);
				if (ComData)
				{
					FMemoryReader MemoryReader(ComData->PtrData, true);
					FObjectAndNameAsStringProxyArchive Ar(MemoryReader, false);
					Ar.ArIsSaveGame = true;
					Ar.ArNoDelta = false;
					Obj->Serialize(Ar);
				}
				if (Obj->Implements<UGetComponentsToSaveByX_Game>())
				{
					IGetComponentsToSaveByX_Game::Execute_OnActorLoad(Obj);
				}
			}
		}
	}
}

void UX_Game_SaveSystem::CustomDeserializeByActorName(AActor* InActor, FString SlotName, FString ObjectName)
{
	USaveActorsDataSlot* SaveGameIns = Cast<USaveActorsDataSlot>(UGameplayStatics::LoadGameFromSlot(SlotName, 0));
	if(!SaveGameIns) return;

	FSaveActorData* actorData = SaveGameIns->actorsSlotData.FindByKey(ObjectName);
	if(actorData)
	{
		LoadActor_Native(InActor,actorData);
		InActor->SetActorTransform(actorData->Transform);
	}
}

void UX_Game_SaveSystem::LoadWorldBP(UObject* WorldContext)
{
	if(LoadWorldSlotName.IsEmpty()) return;
	if(!WorldContext) return;
	
	LoadWorld_Native(WorldContext,LoadWorldSlotName);
}
