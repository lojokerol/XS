﻿// Author: DS_Long
// Publication: 2024-5-24
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/SaveGame.h"
#include "X_GameCharacterSaveGame.generated.h"

USTRUCT()
struct FComponentData
{
	GENERATED_BODY()

	UPROPERTY(SaveGame)
	FString ObjectName;
	
	UPROPERTY(SaveGame)
	TArray<uint8> PtrData;

	UPROPERTY(SaveGame)
	UClass* PtrClass;

	FORCEINLINE bool operator==(const FComponentData& Other) const
	{
		return this->PtrClass == Other.PtrClass;
	}
	
	FORCEINLINE bool operator==(const UClass* Other) const
	{
		return this->PtrClass == Other;
	}
};

/**
 * A structure that stores data
 */
UCLASS()
class X_GAMESAVESYSTEM_API UX_GameCharacterSaveGame : public USaveGame
{
	GENERATED_BODY()

public:
	UPROPERTY(SaveGame)
	TArray<uint8> PtrData = {};

	UPROPERTY(SaveGame)
	TArray<FComponentData> ComponentsData = {};

};

USTRUCT(BlueprintType)
struct FSaveActorData
{
	GENERATED_BODY()
	
public:
	UPROPERTY(SaveGame)
	FString ObjectName;
	
	UPROPERTY(SaveGame)
	TArray<uint8> PtrData = {};

	UPROPERTY(SaveGame)
	UClass* ActorClass;
	
	/*ActorTransform*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite,SaveGame,Category="SaveGameSystme")
	FTransform Transform;
	
	UPROPERTY(SaveGame)
	TArray<FComponentData> ComponentsData = {};

	FORCEINLINE bool operator==(UClass* OtherClass) const
	{
		return ActorClass==OtherClass;
	}
	
	FORCEINLINE bool operator==(FString Name) const
	{
		return ObjectName==Name;
	}
	
	FORCEINLINE bool operator!=(FString Name) const
	{
		return ObjectName!=Name;
	}

	FORCEINLINE bool operator== (const FSaveActorData& Other) const
	{
		return this->ObjectName == Other.ObjectName;
	}

	FORCEINLINE bool operator!= (const FSaveActorData& Other) const
	{
		return this->ObjectName != Other.ObjectName;
	}
};

UCLASS()
class X_GAMESAVESYSTEM_API USaveActorsDataSlot : public USaveGame
{
	GENERATED_BODY()

public:
	UPROPERTY(SaveGame)
	TArray<FSaveActorData> actorsSlotData = {};

	/*日期*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite,SaveGame,Category="SaveGameSystme")
	FString Date;

	/*存档名*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite,SaveGame,Category="SaveGameSystme")
	FString SlotName;

	/*额外的描述信息*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite,SaveGame,Category="SaveGameSystme")
	TArray<FString> OtherDataArr;

	/*关卡名*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite,SaveGame,Category="SaveGameSystme")
	FString MapName;
	
};

USTRUCT(BlueprintType)
struct FMultiArchiveST
{
	GENERATED_BODY()
public:
	/*存档名*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite,SaveGame,Category="SaveGameSystme")
	FString SlotName;
	
	/*日期*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite,SaveGame,Category="SaveGameSystme")
	FString Date;

	/*日期结构体*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite,SaveGame,Category="SaveGameSystme")
	FDateTime DateTime;

	/*额外的描述信息*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite,SaveGame,Category="SaveGameSystme")
	TArray<FString> OtherDataArr;

	/*关卡名*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite,SaveGame,Category="SaveGameSystme")
	FString MapName;
	
	FORCEINLINE bool operator==(const FString& InSlotName)
	{
		return SlotName==InSlotName;
	}
	
	
};
UCLASS()
class X_GAMESAVESYSTEM_API UMultiArchiveData : public USaveGame
{
	GENERATED_BODY()

public:
	UPROPERTY(SaveGame,BlueprintReadWrite,Category="SaveGameSystme")
	TArray<FMultiArchiveST> MultiArchiveSTArr;
};